/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jeupendu;
 import javax.swing.*;
 import java.awt.*;
 import java.awt.event.*;
/**
 *
 * @author ADMIN
 */
public class FenetrePendu  extends JFrame implements ActionListener  {
      private JeuPendu jeu;
      private JLabel motAfficheLabel;
      private JLabel erreursRestantesLabel;
      private JTextField propositionField;
      private JButton proposerButton;
      private JLabel lettresProposeesLabel;
      private JButton nouvellePartieButton;
       
public FenetrePendu(){
    jeu =new JeuPendu();
    
    setTitle("jeu du pendu");
    setSize(400,300);
    
    setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
    
    setLocationRelativeTo(null);
    motAfficheLabel=new JLabel(jeu.getMotDevinePourAffichage(),SwingConstants.CENTER);
    
    motAfficheLabel.setFont(new Font("Monospaced",Font.BOLD,24));
    erreursRestantesLabel=new JLabel("Erreurs Restantes:"+ jeu.getErreursRestantes());
     
    lettresProposeesLabel=new JLabel("Lettres proposées:"+jeu.getLettersProposees());
    
    propositionField=new JTextField(5);
    proposerButton= new JButton("Proposer");
    proposerButton.addActionListener(this);
    
    nouvellePartieButton=new JButton("Nouvele Partie");
        
    nouvellePartieButton.addActionListener(new ActionListener(){
        @Override
        public void actionPerformed(ActionEvent e){
            reinitialiserGUI();
        }
        
    });
    JPanel haut=new JPanel(new GridLayout(2,1));
    haut.add(motAfficheLabel);
    haut.add(erreursRestantesLabel);
    JPanel centre=new JPanel();
    centre.add(new JLabel("Lettre:"));
    centre.add(propositionField);
    centre.add(proposerButton);
    
    JPanel bas =new JPanel(new GridLayout(2,1));
    bas.add(lettresProposeesLabel);
    bas.add(nouvellePartieButton);
    
    setLayout(new BorderLayout());
    add(haut,BorderLayout.NORTH);
    add(centre,BorderLayout.CENTER);
    add(bas,BorderLayout.SOUTH);
    
    setVisible(true);    
}
@Override
public void actionPerformed(ActionEvent e){
    String texte= propositionField.getText().trim();
    if (texte.length()!=1||!Character.isLetter(texte.charAt(0))){
        JOptionPane.showMessageDialog(this,"veuiller entre une seule lettre alphabetique.","erreur",JOptionPane.ERROR_MESSAGE);
        return;
    }
    char lettre=texte.charAt(0);
    String message= jeu. proposerLettre(lettre);
    
    motAfficheLabel.setText(jeu.getMotDevinePourAffichage());
    erreursRestantesLabel.setText("Erreurs restantes:"+jeu.getErreursRestantes());
    lettresProposeesLabel.setText("lettres proposées:"+jeu.getLettresProposees());
    propositionField.setText("");
    
    if (jeu.estGagne()){JOptionPane.showMessageDialog(this, "bravo,belle performance continue comme ça👌👍!","aucun mot ne te resiste ",
            JOptionPane.INFORMATION_MESSAGE);
    proposerButton.setEnabled(false);
            }else if (jeu.estperdu()){
          
                
                JOptionPane.showMessageDialog(this,"tu as été pendu☠️!",
                        "Game over essaie une revanche",JOptionPane.WARNING_MESSAGE);
                proposerButton.setEnabled(false);
            }
    
}
private void reinitialiserGUI(){
    jeu.reinitialiser();
    
    motAfficheLabel.setText(jeu.getMotDevinePourAffichage());
    erreursRestantesLabel.setText("Erreurs restantes :"+jeu.getErreursRestantes());
    lettresProposeesLabel.setText("lettres proposées:"+jeu.getLettresProposees());
    propositionField.setText("");
    
    proposerButton.setEnabled(true);
    
}

}             