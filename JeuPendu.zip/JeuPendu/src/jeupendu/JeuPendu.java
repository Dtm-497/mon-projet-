/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package jeupendu;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.Random;

/**
 *
 * @author ADMIN
 */
public class JeuPendu {
    private String motSecret;
    private StringBuilder  motDevineAffiche;
    
    private ArrayList<Character>lettresProposees;
    private int erreursRestantes;
    private  ArrayList<String>listeMots;
    
    
       
        public JeuPendu(){
            listeMots=new ArrayList<>(Arrays.asList("ordinateur","java","developpeur","avion","universite","artificielle","bitmasking","photosynthèse"
            ,"transitor","climatisation","bureaucratique","substanciel","con","merci","taxi","football"));
            Random rand = new Random();
            motSecret=listeMots.get(rand.nextInt(listeMots.size()));
          motDevineAffiche=new StringBuilder();
          for (int i = 0; i < motSecret.length(); i++){
              motDevineAffiche.append("_");
          }
            lettresProposees=new ArrayList<>();
            erreursRestantes=7;
        }
        
        public String proposerLettre(char lettre){
            lettre=Character.toLowerCase(lettre);
            if
                    (lettresProposees.contains(lettre)){
                return"Lettre deja proposée.";
            }
            lettresProposees.add(lettre);boolean bonneLettre=false;
            
            for(int i=0;i<motSecret.length();i++){
    if(motSecret.charAt(i)==lettre){
        motDevineAffiche.setCharAt(i,lettre);
        bonneLettre=true;
    }
}
        if(!bonneLettre){
    erreursRestantes--;
    return"Lettre incorrecte.";
    }else{
    return"Bonne lettre!";
    }
        }
        public boolean estGagne(){
            return motDevineAffiche.toString().equals(motSecret);
        }
        public boolean estperdu(){
            return erreursRestantes<=0;
        }
        public String getLettresProposees(){
            StringBuilder sb =new StringBuilder();
            for(char c : lettresProposees){
                sb.append(c).append("");
            }
            return sb.toString().trim();
        }
        public String getMotDevinePourAffichage(){
             return motDevineAffiche.toString();
        }
        public int getErreursRestantes(){
            return erreursRestantes;
        }
        public ArrayList<Character>getLettersProposees(){
            return lettresProposees;
        }
        public void reinitialiser(){
            Random rand=new Random();motSecret=listeMots.get(rand.nextInt(listeMots.size()));
           motDevineAffiche=new StringBuilder();
          for (int i =0; i< motSecret.length(); i++){
              motDevineAffiche.append("_");
          }
            lettresProposees.clear();
           erreursRestantes=8;
        }

   
    
        
}
   



 

    
    

